import { Pipe, PipeTransform } from '@angular/core';
import { students } from './model';
@Pipe({
  name: 'filterPipe',
})
export class FilterPipePipe implements PipeTransform {

  transform(representdata: students[] , searchterm: string): students[] {
    console.log("click");
      if(!representdata || !searchterm)
      {
        return representdata
      }
      return representdata.filter(data=>data.name.toLowerCase().indexOf(searchterm.toLowerCase())!=-1)
  }

}
