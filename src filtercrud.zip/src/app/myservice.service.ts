import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { students } from './model';
@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor(private http:HttpClient) { 

  }
  sendingdata(data:students)
  {
    const values={name:data.name,address:data.address};
        return this.http.post("http://localhost:3000/students",values);
  }
  getdata()
  {
      return this.http.get("http://localhost:3000/students");
  }
  deletedata(x:number)
  {
      return this.http.delete("http://localhost:3000/students/"+x);
  }
 
}
