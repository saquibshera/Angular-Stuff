import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

import { students } from './model';
import { MyserviceService } from './myservice.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'filteringandcrud';
  ourform= new FormGroup({
    name:new FormControl(''),
    address:new FormControl(''),
    id:new FormControl('')
  })
  res:students;
  searchterm:string='';
  constructor(private service:MyserviceService)
  {

  }
  representdata:any=[];
  data:any={name:'',address:'',id:-1}
  ngOnInit()
  {
        this.service.getdata().subscribe(res=>
          {
            this.representdata=res;
            console.log(res)
          }
          );
  }

  senddata()
  {
    console.log(this.ourform.value);
    this.data={name:this.ourform.value.name,address:this.ourform.value.address,id:-1};
    this.service.sendingdata(this.data).subscribe(res=>{
     
          console.log("submitted");
          this.ngOnInit();

    })
  }
  deletedata(x:number)
  {
          this.service.deletedata(x).subscribe(res=>
            {
              console.log("deleted successfully");
              this.ngOnInit();
            })
  }

}
