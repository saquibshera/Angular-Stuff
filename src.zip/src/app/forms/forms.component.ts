import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent implements OnInit {

  ourform=new FormGroup({
      name:new FormControl(''),
      surname:new FormControl('')
  })
  constructor() { }

  ngOnInit(): void {
  }
  sendform()
  {
    console.log(this.ourform.value);
  }
}
