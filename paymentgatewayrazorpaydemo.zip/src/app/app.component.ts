import { Component, OnInit } from '@angular/core';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor(private auth:AuthService)
  {
  

  }
  amount:number=0
  
  name:string=''
  orderid=''
  options = {
    "key": "rzp_test_cWTvJJI6z4k0Eu", // Enter the Key ID generated from the Dashboard
    "amount":this.amount, // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
    "currency": "INR",
    "name": "Mobile Programming",
    "description": "Test Transaction",
    "image": "https://example.com/your_logo",
    "order_id": "", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
    // "handler": function (response: { razorpay_payment_id: any; razorpay_order_id: any; razorpay_signature: any; }){
    //     alert(response.razorpay_payment_id);
    //     alert(response.razorpay_order_id);
    //     alert(response.razorpay_signature)
    // },
    "prefill": {
        "name": this.name,
        "email": "gaurav.kumar@example.com",
        "contact": "9999999999"
    },
    "notes": {
        "address": "Razorpay Corporate Office"
    },
    "theme": {
        "color": "#3399cc"
    }
}
  title = 'paymentproject';
  ngOnInit()
  {
    
  }
  rzp1:any
  pay()
  {
    
    this.options.amount=this.amount*100;
    this.rzp1 = new this.auth.nativeWindow.Razorpay(this.options);
   
    this.rzp1.order_id="1234"
    this.rzp1.open()
  }
}
