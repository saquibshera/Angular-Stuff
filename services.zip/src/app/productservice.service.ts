import { Injectable } from '@angular/core';
import {HttpClient,HttpHeaders} from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class ProductserviceService {
  httpheaders=new HttpHeaders({'Content-Type':'application/json'})
  constructor(private http:HttpClient) { }
 
  getdata()
  {
        return this.http.get("http://localhost:3000/prod");
  }
  passdatas(name:string,color:string)
  {
    const data={name,color};
    return this.http.post("http://localhost:3000/prod",data,{headers:this.httpheaders});
  }
}
