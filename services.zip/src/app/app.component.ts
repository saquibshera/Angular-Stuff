import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'servicesproject';
  mydata:any=[];
  name:string='';
  color:string='';
  constructor(private http:ProductserviceService)
  {

  }
  ngOnInit()
  {
   
  }
  senddata()
  {
      this.http.passdatas(this.name,this.color).subscribe(res=>
        console.log(res),
        error=>console.log(error))
  }
}
