import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';
@Component({
  selector: 'app-getproducts',
  templateUrl: './getproducts.component.html',
  styleUrls: ['./getproducts.component.css']
})
export class GetproductsComponent implements OnInit {
  mydata:any='';
  constructor(private service:ProductserviceService) { }
  search:string='';
  ngOnInit(){
    this.service.getdata().subscribe(res=>
      {
        this.mydata=res;
        console.log(this.mydata)
      })
  }

}
