import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ProductserviceService } from '../productservice.service';
@Component({
  selector: 'app-passdata',
  templateUrl: './passdata.component.html',
  styleUrls: ['./passdata.component.css']
})
export class PassdataComponent implements OnInit {
  ourform=new FormGroup({
    name:new FormControl(''),
    color:new FormControl('')
  })
  constructor(private service:ProductserviceService) { }
  
  ngOnInit(): void {
  }
  passdata()
  {
    this.service.passdatas(this.ourform.value.name,this.ourform.value.color).subscribe(res=>
      {
        console.log(res)
      },
      error=>{
      console.log(error)
      }
      )
      
      
    console.log(this.ourform.value);
  }

}
