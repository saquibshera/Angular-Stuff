import { Component } from "@angular/core";


@Component({
        selector:'list',
        template:`<h1>hello</h1>
        <p>This is my page</p>`,
})

export class hello{
                        
}