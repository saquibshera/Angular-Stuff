import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';
@Component({
  selector: 'app-getdata',
  templateUrl: './getdata.component.html',
  styleUrls: ['./getdata.component.css']
})
export class GetdataComponent implements OnInit {
  data:any=[];
  constructor(private service:MyserviceService) { }

  ngOnInit(): void {
      this.service.getdata().subscribe(result=>
        {
          this.data=result;
        console.log(result)},
        error=>console.log(error))
  }

}
