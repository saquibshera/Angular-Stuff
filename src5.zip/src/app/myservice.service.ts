import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor(private http:HttpClient) { }

  getdata()
  {
      return this.http.get("http://localhost:3000/products")
  }

  getusers()
  {
    return this.http.get("https://api.openbrewerydb.org/breweries");
  }
}
