import { Component, OnInit } from '@angular/core';
import { MyserviceService } from '../myservice.service';
@Component({
  selector: 'app-getusers',
  templateUrl: './getusers.component.html',
  styleUrls: ['./getusers.component.css']
})
export class GetusersComponent implements OnInit {
  data:any=[];
  constructor(private service:MyserviceService) { }

  ngOnInit(): void {
        this.service.getusers().subscribe(res=>
          {console.log(res)
            this.data=res;
          },
          error=>console.log(error))
  }

}
