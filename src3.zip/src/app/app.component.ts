import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit,AfterViewInit {
  title = 'projectpassdata';
  name:string="shivam";
  displayhobby:string='';
  @ViewChild('tags') gettag:ElementRef;
  ngOnInit()
  {

  }
  ngAfterViewInit()
  {
        this.gettag.nativeElement.innerHTML="Welcome onboard";
  }
  catchdata(x:string)
  {
      this.displayhobby=x;
  }
}
