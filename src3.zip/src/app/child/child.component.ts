import { Component, Input, OnInit, Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
  @Input() getvalue:string='';
  myhobby:string="gymming";
  @Output() passdata=new EventEmitter();
  constructor() { }

  ngOnInit(): void {
          this.passdata.emit(this.myhobby);
  }

}
