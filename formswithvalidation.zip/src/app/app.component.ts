import { Component } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  buttonname:string="getdata"
  getclassname:string='classy'
  title = 'basicproject';
  displayname:string='';
  count:number=5;
  name:string="himanshuu"
  countryname:string='turkey'
  names:Array<string>=["himashu","uttam","vishal","manju","saquib"]
  twowayvariable:string=''
  representdata:string=''
  // putdata()
  // {
  //     this.representdata=this.twowayvariable
  // }
  // getcolor():string
  // {
  //     switch(this.countryname)
  //     {
  //       case 'india':
  //         return 'blue'
  //       case 'nepal':
  //         return 'yellow'
  //       case 'turkey':
  //         return 'maroon'
  //       default:
  //         return 'white'
  //     }
  // }
  // display()
  // {
  //     this.displayname="yoyooo welcome angular";
  // }
  // getclass()
  // {
  //       if(this.getclassname=="classy")
  //       {
  //         return true;
  //       }
  //       else{
  //         return false;
  //       }
  // }
  dataarray=[
    {
      name:'',
      comment:'',
      email:''
    }
  ]
  ourform= new FormGroup({
    name:new FormControl('',Validators.required),
    email:new FormControl('',[Validators.required,Validators.email]),
    comment:new FormControl('',[Validators.required,Validators.minLength(20)]),
    phone : new FormControl(
      '',
      [
        Validators.required,
        Validators.pattern('^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{4})(?: *x(\\d+))?\\s*$')
      ]),
  })
  sendform()
  {
        console.log(this.ourform.value);
        const data={name:this.ourform.value.name,comment:this.ourform.value.comment,email:this.ourform.value.email}
        this.dataarray.push(data);
        console.log(this.dataarray)
  }
}
