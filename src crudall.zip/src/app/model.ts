export class students{
    name:string='';
    address:string='';
    id:number=-1;
}