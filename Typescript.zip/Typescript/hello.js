var basics = /** @class */ (function () {
    function basics() {
    }
    basics.prototype.abc = function () {
        console.log("hello");
    };
    return basics;
}());
var obj = new basics(); //instance of a class
obj.abc();
obj.name = "saquib";
console.log(obj.name);
