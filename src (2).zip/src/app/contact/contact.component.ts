import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  constructor(private route:ActivatedRoute,private location:Location) { }

  ngOnInit(): void {
        let id=this.route.snapshot.paramMap.get('id');
        console.log(id);
  }
  getback()
  {
        this.location.back();
  }

}
