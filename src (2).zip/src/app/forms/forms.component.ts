import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent implements OnInit {
  incorrect=''
  formdata=[{
    name:'saquib',
    surname:'bhat'
  },
  {
    name:'sagar',
    surname:'sharma'
  },
  {
    name:'Tushar',
    surname:'Arora'
  },
]
  ourform=new FormGroup({
      name:new FormControl(''),
      surname:new FormControl('')
  })
  item:any;
  constructor(private route:Router) { }

  ngOnInit(): void {
    this.item=localStorage.getItem('form');
  }

  sendform()
  {
    localStorage.setItem('form',JSON.stringify(this.ourform.value));
      for(var i=0;i<=this.formdata.length;i++)
      {
        if(this.ourform.value.name==this.formdata[i].name && this.ourform.value.surname==this.formdata[i].surname)
        {
            this.route.navigate(['welcome'])
        }
        else{
              this.incorrect="wrong name and surname"
        }
      }
    // this.formdata.push({
    //   name:this.ourform.value.name,
    //   surname:this.ourform.value.surname
    // })
    // console.log(this.ourform.value);
      
  }
  deleteitem()
  {
      localStorage.removeItem('form');
      this.ngOnInit();
  }
}
