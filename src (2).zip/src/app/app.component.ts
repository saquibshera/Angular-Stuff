import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  constructor()
  {
      
  }
  ngOnInit()
  {
    console.log("hello")
  }
  countcolor:number=0;
  buttonvalue:string="click here"
  myname:Array<string>=[];
  count:number=0;
  getvalue:string='';
  title = 'angularfirstproject';
  person:Array<string>=["aamir","saquib"];
  persons:any=[
    {
      firstname:'shivam',
      address:'delhi',
      mno:'9906123456'
    },
    {
      firstname:'praveen',
      address:'delhi',
      mno:'9906123456'
    },
    {
      firstname:'Astha',
      address:'hyderabad',
      mno:'9906123456'
    },
    {
      firstname:'Astha',
      address:'mumbai',
      mno:'9906123456'
    },
  ]
  getcolor(address:string)
  {
      switch(address){
      case 'delhi':
        return 'blue';
      case 'hyderabad':
        return 'green'
      default:
        return 'orange';

      }

  }
  mymethod()
  {
        this.myname.push(this.getvalue);
        this.count+=1;
  }
  changecolor()
  {
    this.countcolor+=1;
  }
  getclass()
  {
      let classes={
        myclass:this.countcolor<=5,
        myclass2:this.countcolor>5
      }
      return classes;
      
  }
 
}
